# Handoff: Rediseño de la Hoja de Valoración (grc-front)

## Prompt para Claude Code
Copia esta carpeta a la raíz de `grc-front` y pega en Claude Code:

> Lee `design_handoff_hoja_valoracion/README.md` y el prototipo `Hoja de Valoracion Rediseno.dc.html`. Desde `develop` crea la rama `feature/rediseno-hoja-valoracion` (Git Flow). Implementa el documento nuevo siguiendo el README: reutiliza las variables de `src/styles/global.css` y los componentes de `src/components/ui.jsx`, no agregues librerías y no cambies el backend. Antes de tocar código, muéstrame el plan de archivos y espera mi aprobación. Al terminar ejecuta `npm run build` y `npm run lint`, verifica que `/valoracion` y `/ordenes/:id/valoracion` siguen funcionando y dame el resumen del commit.

## Overview
Nueva hoja de valoración en papel (vista previa, impresión y PDF) para la feature de valoración de GRC. Reemplaza el `DocumentoValoracion` de `src/components/valoracion/PdfViewerModal.jsx`. **El formulario `HojaValoracion.jsx` no cambia.**

## About the Design Files
`Hoja de Valoracion Rediseno.dc.html` es una **referencia de diseño en HTML**, no código de producción. Recréalo en React dentro de grc-front, con sus patrones (componentes funcionales, CSS por archivo con variables de `global.css`). Los datos del prototipo son de muestra; en producción salen de `valoracionService.desdeBackend` y `ordenService.ordenDesdeBackend`.

## Fidelity
**Alta fidelidad.** Los tamaños, colores y tipografía son finales. Recrea la hoja píxel a píxel.

## Regla principal: siempre UNA página carta
- Hoja de 816×1056 px (8.5×11 in a 96 dpi), con `overflow: hidden` y padding de 40px, 44px y 32px.
- Con más de 14 piezas en total, cada tabla (Sustitución, Reparación, Pintura) se divide en **2 columnas** lado a lado: la mitad de las filas (redondeada hacia arriba) en la columna izquierda y el resto en la derecha. El gap entre columnas es de 18px.
- Con más de 36 piezas pasa a modo denso: tamaño de letra de la tabla de 10.5px a 9.5px y padding vertical de las filas de 3px a 1.5px.
- El bloque de tablas usa `flex:1; min-height:0; overflow:hidden`. El resumen y el pie quedan fijos abajo.
- **No hay firmas.** Se eliminaron Valoró, Asesor y Cliente.
- **No hay columna de observación por pieza.**

## Estructura de la hoja (de arriba abajo, gap de 12px)
1. **Encabezado** (en flex, con space-between):
   - A la izquierda va un cuadrado naranja #FF6B1A de 11px con radio de 2px y "SERVIMACROMOTOR" en Barlow Condensed 700 a 19px. Debajo, "HOJA DE VALORACIÓN DE DAÑOS" en IBM Plex Mono a 8.5px, con tracking de 0.14em y color #595959.
   - A la derecha, en una sola línea en Plex Mono a 10px y `nowrap`:
     - "ORDEN" (etiqueta a 8px #595959) + `fmtOrden(orden.numero)`
     - "FECHA" + `actualizadaAt || creadaAt`, con el formato "26 AGO 2026"
     - Una píldora de estado con borde de 1px #0D0D0D, radio de 20px, padding de 2px y 8px, y un punto de 6px. Muestra "PENDIENTE CESVI" con punto #FF6B1A o "EN CESVI" con punto #3FB950, según `cargadaCesvi`.
2. **Regla** de 2px #0D0D0D.
3. **Datos** en una grilla de 3 columnas iguales con gap de 22px. Cada grupo lleva:
   - Un título en Barlow Condensed 700 a 11.5px, en mayúsculas, con borde inferior de 1px #0D0D0D.
   - Filas con grilla `78px 1fr`: etiqueta en Plex Mono a 8px #595959 y valor en Barlow 600 a 10.5px, con borde inferior de 0.5px #D9D9D9 y padding de 2px.

   Los grupos y sus campos:
   - **Datos generales:**
     - CLIENTE: `cliente.nombre`
     - DOCUMENTO: `cliente.documento`
     - CELULAR: `cliente.celular`
     - CORREO: `cliente.correo`
     - VALORÓ: `valoracion.usuario`
     - ASESOR: `orden.asesor`
   - **Vehículo:**
     - PLACA: `placa`, en mono
     - MARCA: `vehiculo.marca`
     - MODELO: `vehiculo.modelo`
     - AÑO: `vehiculo.anio`
     - COLOR: `vehiculo.color`
     - VIN: `vehiculo.vin`, en mono
   - **Siniestro y aseguradora:**
     - N.º SINIESTRO: `orden.siniestro`, en mono y con "—" si está vacío
     - ESTADO CESVI
     - FECHA CARGA: `cargadaCesviAt`
     - REG. ORDEN: `orden.fechaCreacion`
4. **Descripción** en una fila con grilla `78px 1fr`: la etiqueta "DESCRIPCIÓN" y `valoracion.descripcion` a 10.5px #262626 con line-height de 1.4. Si está vacía, muestra "Sin descripción registrada."
5. **Bloques de piezas**, con gap de 10px y en este orden:
   - I · SUSTITUCIÓN: `accion = SUSTITUIR`
   - II · REPARACIÓN: `accion = REPARAR`
   - III · PINTURA: `accion = PINTAR` (ver la nota de backend)

   Cada bloque tiene:
   - **Cabecera** en grilla `1fr auto 1fr`. El título va **centrado** en Barlow Condensed 700 a 12.5px, con tracking de 0.08em. A la derecha va el conteo ("4 PIEZAS" / "1 PIEZA") en Plex Mono a 8.5px #595959.
   - **Tabla** con las columnas #, PIEZA, OPER. y CANT.:
     - La columna OPER. ocupa 38px en Sustitución y muestra "S".
     - En Reparación y Pintura esa columna se llama GRAVEDAD, ocupa 62px y muestra LEVE, MEDIA o GRAVE (`detalle.gravedad`).
     - Las cabeceras van en Plex Mono 500 a 7.5px #595959, con borde inferior de 1.5px #0D0D0D.
     - Las celdas llevan borde inferior de 0.5px #D9D9D9. El # va con 2 dígitos ("01").
     - CANT. va alineada a la derecha, en mono 600 a 9.5px.
     - Las piezas se ordenan alfabéticamente (`localeCompare('es')`).
   - **Estado vacío:** "Ninguna pieza por sustituir. / reparar. / pintar." a 10.5px #595959.
6. **Resumen** alineado a la derecha, con 230px de ancho:
   - "Piezas a sustituir / reparar / pintar" con su número.
   - "TOTAL PIEZAS" con borde superior de 1.5px #0D0D0D, en Barlow Condensed 700 a 12.5px.
7. **Pie:** "VALORÓ: {USUARIO} · {PLACA}" a la izquierda y "PÁGINA 1 DE 1" a la derecha, en Plex Mono a 8px #595959 con borde superior de 0.5px #BFBFBF.

## Vista en la app (ValoracionPdfView)
La hoja va dentro de un panel `.card` (#262626 con borde #595959 y radio de 10px), cuyo título es "Previsualización · hoja.pdf" con el meta "N PIEZAS · 1 PÁGINA". La columna lateral es de 260px y tiene:
- **Descargas:**
  - "IMPRIMIR / GUARDAR PDF" (botón primario, abre `window.print()`)
  - Descargar PDF
  - Descargar ZIP de fotos
  - Editar hoja
  - Ver en pantalla completa
- **CESVI Colombia:** el texto de estado y el botón "Marcar como cargada" si está pendiente.

Mantén el comportamiento actual de esos botones. Si el contenedor es más angosto que la hoja, el panel hace scroll horizontal.

## Móvil (< 640px)
No se muestra la hoja en papel. En su lugar va una pila de tarjetas `.card` con gap de 12px:
- Datos generales, Vehículo y Siniestro, en grilla de 2 columnas.
- Descripción.
- Una tarjeta por bloque, con una fila por pieza: el nombre y debajo "SUSTITUIR" o "LEVE/MEDIA/GRAVE", y "× cant" a la derecha.
- El resumen.
- El botón "Imprimir / guardar PDF" a ancho completo, con alto mínimo de 44px.

## Impresión (@media print)
```css
@page { size: letter; margin: 0; }
@media print {
  body * { visibility: hidden; }
  .hvd-sheet, .hvd-sheet * { visibility: visible; }
  .hvd-sheet { position: fixed; inset: 0; width: 8.5in; height: 11in; box-shadow: none; }
  .sidebar, .topbar, .hvd-aside, .hvd-toolbar { display: none !important; }
  .hvd-sheet tr { break-inside: avoid; }
  * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
}
```
La salida es siempre una sola página, porque la hoja tiene el alto fijo de una carta.

## Estados
- **Cargando:** un spinner de 18px (borde de 2px #595959, borde superior #FF6B1A, giro de 0.8s lineal) y el texto "CARGANDO VALORACIÓN" en Plex Mono a 10px.
- **Sin piezas:** se muestra el texto vacío en cada bloque, con totales en 0.
- **Sin siniestro o campos vacíos:** se muestra "—".

## Design tokens (de `global.css` de GRC)
- **Colores:**
  - #0D0D0D (tinta y fondo de la app)
  - #262626 (tarjetas)
  - #595959 (bordes y texto secundario)
  - #BFBFBF (texto en el modo oscuro)
  - #D9D9D9 (líneas de tabla)
  - #F2F2F2 (texto claro)
  - #FFFFFF (papel)
  - #FF6B1A (acento)
  - #3FB950 (OK)
- **Fuentes:**
  - Barlow 400 a 700 (texto)
  - Barlow Condensed 600 y 700 (títulos)
  - IBM Plex Mono 400 a 600 (etiquetas, números, placa y VIN)
- **Radios:** botones de 6px, tarjetas de 10px y píldoras de 20px.

## Archivos a crear o modificar en grc-front
- **Crear:**
  - `src/components/valoracion/HojaValoracionDocumento.jsx`, con las props `valoracion` y `orden`
  - `src/styles/HojaValoracionDocumento.css`, con prefijo `hvd-` y las reglas responsive y de print
- **Modificar:**
  - `src/components/valoracion/PdfViewerModal.jsx`: usar el documento nuevo
  - `src/components/valoracion/ValoracionPdfView.jsx`: botón "Imprimir / guardar PDF"
  - `src/utils/valoracionExport.js`: solo si el PDF se genera desde el mismo nodo
  - `src/components/valoracion/HojaValoracion.jsx` y `src/utils/constants.js`: solo si se aprueba PINTURA en el formulario (ver la nota)
- **No tocar:** los servicios, el backend ni `global.css`.

## ⚠ Nota de backend: PINTURA
Hoy el enum de acción del detalle solo tiene `SUSTITUIR` y `REPARAR`. Para guardar piezas de pintura hace falta que el backend acepte `PINTAR`, con `gravedad` igual que en reparación. Hay dos caminos:
- Implementar solo el bloque visual: aparece vacío hasta que exista el dato.
- Coordinar el cambio del enum en Spring Boot y MariaDB antes del merge.

Claude Code debe preguntar antes de tocar cualquier cosa del backend.

## Campos omitidos (no existen en GRC)
- Logos de aseguradora y CESVI, empresa, ciudad y analista externo
- Consecutivo, fecha del siniestro, cierres y modificaciones
- Acabado, tipo de pintura, kilometraje, amparo y póliza
- Valor hora, valores unitarios, subtotales, IVA y totales en COP
- Firmas
- Observación por pieza

## Files
- `Hoja de Valoracion Rediseno.dc.html`: prototipo con 3 vistas (escritorio, móvil 360 e impresión carta) y el botón de ejemplo "MUCHAS PIEZAS".
